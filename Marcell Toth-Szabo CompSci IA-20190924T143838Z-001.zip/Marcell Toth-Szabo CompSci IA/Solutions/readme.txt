To run product:
1. Open a Google Sheets at https://docs.google.com/spreadsheets/
2. Once spreadsheet is open, open "tools" on menu bar and click on "script editor".
3. Copy code from file "code.gs" in this folder and paste in Google Script Editor, replacing any contents in editor.
4. Save the script in Google Script Editor and reload the Google spreadsheet.
5. Give script permission to run when prompted to do so.